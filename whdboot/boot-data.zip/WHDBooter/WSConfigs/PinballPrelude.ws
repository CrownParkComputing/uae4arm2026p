C1:L:Select Table:Prehistoric,Present,Future;
C2:B:Quit with Left Mouse Button;
C3:B:Enable Enhanced High Score;
